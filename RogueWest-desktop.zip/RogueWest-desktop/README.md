# RogueWest — PC build
Electron wrapper for the RogueWest game. GitHub Actions builds:
- Windows: RogueWest-Setup.exe (installer) and RogueWest-Portable.exe (no install)
- macOS: RogueWest.dmg
- Linux: RogueWest.AppImage
Local build: `npm install && node prepare-fonts.js && npm run dist`
